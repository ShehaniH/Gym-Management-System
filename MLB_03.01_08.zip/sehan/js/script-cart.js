function toggleSelectAll(){
    
}

function navigateToCart(){
    window.location.href = "shopingCart.html";
}

function openPaymentMethords(){
    window.location.href = "paymentGateway.html";
}